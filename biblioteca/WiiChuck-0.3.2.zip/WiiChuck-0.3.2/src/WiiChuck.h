#ifndef WiiChuck_h
#define WiiChuck_h

#include <Accessory.h>


#endif
